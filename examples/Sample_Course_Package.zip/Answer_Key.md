# Answer Key & Rubrics - Python for Bioinformatics: 4 Weeks Intermediate Learning Path

### MCQ: Module 1 Concept Check

Which option best shows a learner achieving this objective: "Explain the core concepts of Python for Bioinformatics."

A. By applying it to a realistic Python for Bioinformatics task and checking the result.
B. By memorising terms without ever using them.
C. By avoiding practical application altogether.
D. By skipping any evaluation of the results.

**Answer:** A. By applying it to a realistic Python for Bioinformatics task and checking the result.
**Mapped objective:** Explain the core concepts of Python for Bioinformatics.

### QUIZ: Module 1 Short Quiz

In 2-3 sentences, show how you would meet this objective: "Apply the essential terminology and tools of Python for Bioinformatics."

**Answer:** A strong answer names the key Python for Bioinformatics concept from 'Foundations of Python for Bioinformatics' and gives one concrete example.
**Mapped objective:** Apply the essential terminology and tools of Python for Bioinformatics.

### MCQ: Module 2 Concept Check

Which option best shows a learner achieving this objective: "Explain the standard workflow used in Python for Bioinformatics."

A. By memorising terms without ever using them.
B. By applying it to a realistic Python for Bioinformatics task and checking the result.
C. By avoiding practical application altogether.
D. By skipping any evaluation of the results.

**Answer:** B. By applying it to a realistic Python for Bioinformatics task and checking the result.
**Mapped objective:** Explain the standard workflow used in Python for Bioinformatics.

### QUIZ: Module 2 Short Quiz

In 2-3 sentences, show how you would meet this objective: "Apply which tool or method suits a given Python for Bioinformatics problem."

**Answer:** A strong answer names the key Python for Bioinformatics concept from 'Core Concepts and Tools' and gives one concrete example.
**Mapped objective:** Apply which tool or method suits a given Python for Bioinformatics problem.

### MCQ: Module 3 Concept Check

Which option best shows a learner achieving this objective: "Analyze the workflow to a realistic Python for Bioinformatics scenario."

A. By memorising terms without ever using them.
B. By avoiding practical application altogether.
C. By applying it to a realistic Python for Bioinformatics task and checking the result.
D. By skipping any evaluation of the results.

**Answer:** C. By applying it to a realistic Python for Bioinformatics task and checking the result.
**Mapped objective:** Analyze the workflow to a realistic Python for Bioinformatics scenario.

### QUIZ: Module 3 Short Quiz

In 2-3 sentences, show how you would meet this objective: "Apply errors and unexpected results in Python for Bioinformatics work."

**Answer:** A strong answer names the key Python for Bioinformatics concept from 'Python for Bioinformatics in Practice' and gives one concrete example.
**Mapped objective:** Apply errors and unexpected results in Python for Bioinformatics work.

### MCQ: Module 4 Concept Check

Which option best shows a learner achieving this objective: "Apply a complete Python for Bioinformatics solution for a defined goal."

A. By memorising terms without ever using them.
B. By avoiding practical application altogether.
C. By skipping any evaluation of the results.
D. By applying it to a realistic Python for Bioinformatics task and checking the result.

**Answer:** D. By applying it to a realistic Python for Bioinformatics task and checking the result.
**Mapped objective:** Apply a complete Python for Bioinformatics solution for a defined goal.

### QUIZ: Module 4 Short Quiz

In 2-3 sentences, show how you would meet this objective: "Analyze the solution against clear success criteria."

**Answer:** A strong answer names the key Python for Bioinformatics concept from 'Applied Project' and gives one concrete example.
**Mapped objective:** Analyze the solution against clear success criteria.

### ASSIGNMENT: Applied Task

Complete a small task showing practical use of Python for Bioinformatics. Document your approach, result and one limitation.

**Answer:** Instructor evaluates the submitted work against the rubric.
**Mapped objective:** Analyze the workflow to a realistic Python for Bioinformatics scenario.
**Rubric:** 4 - accurate, complete and well justified; 3 - mostly correct; 2 - partial; 1 - insufficient evidence.

### PROJECT: Capstone Mini-Project

Design a mini-project addressing: Build practical Python skills for biological sequence analysis. Include objective, method, output and evaluation.

**Answer:** Project-specific; evaluate against objective, method, evidence and reflection.
**Mapped objective:** Analyze the solution against clear success criteria.
**Rubric:** 4 - strong alignment and evidence; 3 - adequate alignment; 2 - major gaps; 1 - incomplete.

